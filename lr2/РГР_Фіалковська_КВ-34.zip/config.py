PG_DSN = (
#bd location
    "host=localhost "
    "port=5432 "
    "dbname=postgres "
    "user=postgres "
    "password=fialkaolya08"
)
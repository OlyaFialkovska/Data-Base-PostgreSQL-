# main.py
from controller import run

if __name__ == "__main__":
    print("Консольний додаток РГР (CRUD + валідація + FK помилки).")
    print("Перед запуском змініть DSN у config.py.")
    run()
